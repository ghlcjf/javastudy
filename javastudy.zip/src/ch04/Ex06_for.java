package ch04;

public class Ex06_for {

	public static void main(String[] args) {
		// for 반복을 이용한 1부터 10까지 출력
		
		for (int i=1,j=100; i<=10 || j>0; i++,j--) { //(초기값; 조건; 증감식)
			System.out.println("i : "+i);
		}
		
		
		
		
		
		
		
		
		

	}

}
