package ch03;

public class Ex01 {
	public static void main(String[] args) {
		int a = 5, b = 3;
		System.out.println("a/b = "+(a/b)); // 연산 결과 : int 타입 => 1
		
		// 우리가 원하는 결과는 1.6666....
		
		System.out.println("a/b = "+((double)a/b));
		
		
		
	
}
}
