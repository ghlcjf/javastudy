package ch1;

public class answer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "홍길동";
		int age = 27;
		System.out.println("이름 : "+name);
		System.out.printf("나이 : %d\n",age);
		System.out.println("연락처 : 010-1234-5678");
		
		//제작일 : 2022-09-13 10:49
		//버전 : version.0.1.1
		
		
		
		
	}

}
